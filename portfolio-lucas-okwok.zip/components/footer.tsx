'use client'

import { useLanguage } from './language-provider'

export function Footer() {
  const { t } = useLanguage()
  const currentYear = new Date().getFullYear()

  return (
    <footer className="py-8 border-t border-border">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>
            © {currentYear} Lucas Okwok. {t.footer.rights}
          </p>
          <p className="font-mono text-xs">
            Built with React + TypeScript + Next.js
          </p>
        </div>
      </div>
    </footer>
  )
}
