'use client'

import { Github, Linkedin, Mail } from 'lucide-react'
import { useLanguage } from './language-provider'
import { socialLinks } from '@/lib/data'

export function Contact() {
  const { t } = useLanguage()

  return (
    <section id="contact" className="py-24">
      <div className="max-w-6xl mx-auto px-6">
        <div className="max-w-2xl mx-auto text-center space-y-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
            {t.contact.title}
          </h2>
          
          <p className="text-lg text-muted-foreground leading-relaxed">
            {t.contact.description}
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <a
              href={socialLinks.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-6 py-3 bg-card border border-border rounded-xl text-foreground font-medium hover:border-primary hover:text-primary transition-colors"
            >
              <Linkedin className="w-5 h-5" />
              LinkedIn
            </a>
            <a
              href={socialLinks.github}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-6 py-3 bg-card border border-border rounded-xl text-foreground font-medium hover:border-primary hover:text-primary transition-colors"
            >
              <Github className="w-5 h-5" />
              GitHub
            </a>
            <a
              href="mailto:contato@lucasokwok.dev"
              className="inline-flex items-center gap-3 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors"
            >
              <Mail className="w-5 h-5" />
              E-mail
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
