'use client'

import { GraduationCap, Award } from 'lucide-react'
import { useLanguage } from './language-provider'
import { education } from '@/lib/data'

export function Education() {
  const { language, t } = useLanguage()

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'inProgress':
        return t.education.inProgress
      case 'complete':
        return t.education.complete
      case 'highlight':
        return t.education.highlight
      default:
        return ''
    }
  }

  return (
    <section id="education" className="py-24 lg:py-32 bg-muted/30">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section header */}
        <div className="mb-16">
          <h2 className="text-2xl sm:text-3xl font-semibold text-foreground tracking-tight mb-3">
            {t.education.title}
          </h2>
          <p className="text-muted-foreground max-w-xl">
            Formacao academica solida com foco em tecnologia e computacao.
          </p>
        </div>

        {/* Education list */}
        <div className="grid sm:grid-cols-3 gap-6">
          {education.map((edu) => {
            const isHighlight = edu.status === 'highlight'
            
            return (
              <article
                key={edu.id}
                className={`p-6 rounded-lg border ${
                  isHighlight 
                    ? 'bg-primary/5 border-primary/20' 
                    : 'bg-card border-border'
                }`}
              >
                <div className="flex items-center gap-2 mb-4">
                  {isHighlight ? (
                    <Award className="w-5 h-5 text-primary" />
                  ) : (
                    <GraduationCap className="w-5 h-5 text-muted-foreground" />
                  )}
                  <span className={`text-xs font-medium ${isHighlight ? 'text-primary' : 'text-muted-foreground'}`}>
                    {getStatusLabel(edu.status)}
                  </span>
                </div>

                <h3 className="font-semibold text-foreground mb-2">
                  {edu.degree[language]}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {edu.institution}
                </p>
              </article>
            )
          })}
        </div>
      </div>
    </section>
  )
}
