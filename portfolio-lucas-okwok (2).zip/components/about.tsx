'use client'

import { useLanguage } from './language-provider'

export function About() {
  const { t } = useLanguage()

  return (
    <section id="about" className="py-24 lg:py-32 bg-muted/30">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Content */}
          <div>
            <h2 className="text-2xl sm:text-3xl font-semibold text-foreground tracking-tight mb-6">
              {t.about.title}
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>{t.about.content}</p>
              <p>{t.about.education}</p>
            </div>
          </div>

          {/* Key info */}
          <div className="lg:pl-8 lg:border-l lg:border-border">
            <div className="space-y-6">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Localizacao</p>
                <p className="font-medium text-foreground">Sao Jose dos Campos, SP</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Disponibilidade</p>
                <p className="font-medium text-foreground">Aberto a oportunidades</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Posicao atual</p>
                <p className="font-medium text-foreground">Estagiario em Desenvolvimento de Sistemas</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Formacao</p>
                <p className="font-medium text-foreground">Ciencia da Computacao - UNIFESP</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
