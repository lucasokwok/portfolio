'use client'

import Image from 'next/image'
import { Lock, Monitor, FileCode, BarChart3, Layers, Scale, ImageIcon } from 'lucide-react'
import { useLanguage } from './language-provider'
import { projects } from '@/lib/data'

const typeIcons: Record<string, typeof Monitor> = {
  'Web App': Monitor,
  'Desktop Automation': FileCode,
  'Automacao Desktop': FileCode,
  'Legal Automation': Scale,
  'Automacao Juridica': Scale,
  'Power Apps': Layers,
  'Business Intelligence': BarChart3,
}

export function Projects() {
  const { language, t } = useLanguage()

  const getTitle = (title: string | { pt: string; en: string }) => {
    return typeof title === 'string' ? title : title[language]
  }

  return (
    <section id="projects" className="py-24 lg:py-32">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section header */}
        <div className="mb-16">
          <h2 className="text-2xl font-semibold text-foreground tracking-tight mb-3">
            {t.projects.title}
          </h2>
          <p className="text-muted-foreground max-w-2xl text-sm leading-relaxed">
            {language === 'pt' 
              ? 'Solucoes desenvolvidas em ambientes corporativos com foco em resolucao de problemas reais e impacto mensuravel.'
              : 'Solutions developed in corporate environments focused on solving real problems and measurable impact.'
            }
          </p>
        </div>

        {/* Case Study Cards */}
        <div className="space-y-6">
          {projects.map((project, index) => {
            const projectType = project.type[language]
            const Icon = typeIcons[projectType] || Monitor
            
            return (
              <article
                key={project.id}
                className="bg-card border border-border rounded-lg overflow-hidden hover:border-primary/30 transition-colors"
              >
                <div className="grid lg:grid-cols-[1fr,320px]">
                  {/* Content */}
                  <div className="p-6 lg:p-8">
                    {/* Header with type badge and confidential label */}
                    <div className="flex flex-wrap items-center gap-3 mb-4">
                      <div className="flex items-center gap-2 px-2.5 py-1 bg-primary/10 rounded text-xs font-medium text-primary">
                        <Icon className="w-3.5 h-3.5" />
                        <span>{projectType}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Lock className="w-3 h-3" />
                        <span>{t.projects.corporateProject}</span>
                      </div>
                    </div>

                    {/* Project number and title */}
                    <div className="flex items-baseline gap-3 mb-3">
                      <span className="text-xs font-mono text-muted-foreground">
                        {String(index + 1).padStart(2, '0')}
                      </span>
                      <h3 className="text-xl font-semibold text-foreground">
                        {getTitle(project.title)}
                      </h3>
                    </div>

                    {/* Description */}
                    <p className="text-sm text-muted-foreground leading-relaxed mb-5 max-w-2xl">
                      {project.description[language]}
                    </p>

                    {/* Problem solved section */}
                    <div className="mb-5 p-4 bg-muted/40 rounded-md border-l-2 border-primary/50">
                      <p className="text-xs font-medium text-foreground/70 uppercase tracking-wide mb-1.5">
                        {language === 'pt' ? 'Problema resolvido' : 'Problem solved'}
                      </p>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {project.problem[language]}
                      </p>
                    </div>

                    {/* Technologies */}
                    <div className="mb-5">
                      <p className="text-xs font-medium text-foreground/70 uppercase tracking-wide mb-2">
                        {language === 'pt' ? 'Tecnologias' : 'Technologies'}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {project.tags.map((tag) => (
                          <span
                            key={tag}
                            className="px-2 py-0.5 text-xs font-mono bg-background border border-border rounded text-muted-foreground"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Metric */}
                    <div className="pt-5 border-t border-border">
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-semibold text-primary">
                          {project.metric.value}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {project.metric.label[language]}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Visual placeholder */}
                  <div className="hidden lg:flex bg-muted/30 border-l border-border flex-col items-center justify-center p-6">
                    <div className="w-full h-full min-h-[280px] relative">
                      {project.image ? (
                        <div className="relative w-full h-full rounded-md overflow-hidden border border-border bg-background/50 group">
                          <Image
                            src={project.image}
                            alt={`Screenshot: ${getTitle(project.title)}`}
                            fill
                            className="object-cover object-top transition-transform duration-500 group-hover:scale-105"
                            sizes="320px"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                      ) : (
                        <div className="w-full h-full bg-background/50 border border-dashed border-border rounded-md flex flex-col items-center justify-center gap-3">
                          <ImageIcon className="w-10 h-10 text-muted-foreground/30" />
                          <div className="text-center">
                            <p className="text-xs text-muted-foreground">
                              {language === 'pt' ? 'Adicionar screenshot' : 'Add screenshot'}
                            </p>
                            <p className="text-[10px] text-muted-foreground/60 mt-1 font-mono">
                              {project.image?.split('/').pop() || `${project.id}.png`}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            )
          })}
        </div>
      </div>
    </section>
  )
}
