'use client'

import { MapPin } from 'lucide-react'
import { useLanguage } from './language-provider'
import { experiences } from '@/lib/data'

export function Experience() {
  const { language, t } = useLanguage()

  const getCompany = (company: string | { pt: string; en: string }) => {
    return typeof company === 'string' ? company : company[language]
  }

  return (
    <section id="experience" className="py-24">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-12">
          {t.experience.title}
        </h2>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-0 md:left-8 top-0 bottom-0 w-px bg-border" />

          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <article
                key={exp.id}
                className="relative pl-8 md:pl-20"
              >
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-8 -translate-x-1/2 w-4 h-4 rounded-full bg-primary border-4 border-background" />

                <div className="bg-card border border-border rounded-xl p-6 space-y-4">
                  {/* Header */}
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <h3 className="text-xl font-semibold text-foreground">
                        {exp.role[language]}
                      </h3>
                      <span className="text-sm font-mono text-primary bg-primary/10 px-3 py-1 rounded-full">
                        {exp.period[language]}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-muted-foreground">
                      <span className="font-medium text-foreground/80">
                        {getCompany(exp.company)}
                      </span>
                      <span className="flex items-center gap-1 text-sm">
                        <MapPin className="w-4 h-4" />
                        {exp.location}
                      </span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-muted-foreground leading-relaxed">
                    {exp.description[language]}
                  </p>

                  {/* Technologies */}
                  {exp.technologies && (
                    <div className="flex flex-wrap gap-2 pt-2">
                      {exp.technologies.map((tech) => (
                        <span
                          key={tech}
                          className="px-2.5 py-1 text-xs font-mono bg-secondary rounded-md text-primary"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
