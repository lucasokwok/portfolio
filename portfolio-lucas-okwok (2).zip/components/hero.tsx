'use client'

import Image from 'next/image'
import { ArrowRight, MapPin, Linkedin, User } from 'lucide-react'
import { useLanguage } from './language-provider'
import { socialLinks } from '@/lib/data'

const techBadges = [
  { name: 'React', position: 'top-8 right-[45%]' },
  { name: 'TypeScript', position: 'top-24 right-[25%]' },
  { name: 'Python', position: 'top-48 right-[15%]' },
  { name: 'Power BI', position: 'bottom-48 right-[20%]' },
  { name: 'Automation', position: 'bottom-32 right-[40%]' },
]

export function Hero() {
  const { t, language } = useLanguage()

  return (
    <section className="min-h-screen flex items-center pt-16 relative overflow-hidden">
      {/* Tech badges - desktop only */}
      <div className="hidden xl:block absolute inset-0 pointer-events-none">
        {techBadges.map((badge) => (
          <span
            key={badge.name}
            className={`absolute ${badge.position} px-3 py-1.5 text-xs font-mono text-muted-foreground/50 border border-border/30 rounded bg-background/50 backdrop-blur-sm`}
          >
            {badge.name}
          </span>
        ))}
      </div>

      <div className="max-w-6xl mx-auto px-6 py-20 lg:py-28 w-full">
        <div className="grid lg:grid-cols-[1fr,380px] gap-12 lg:gap-16 items-center">
          {/* Left content */}
          <div>
            {/* Status */}
            <div className="flex items-center gap-3 text-sm text-muted-foreground mb-6">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                {language === 'pt' ? 'Disponivel para oportunidades' : 'Open to opportunities'}
              </span>
            </div>

            {/* Name */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold text-foreground tracking-tight mb-3">
              Lucas Okwok
            </h1>

            {/* Role */}
            <p className="text-xl sm:text-2xl text-primary font-medium mb-6">
              Full Stack Developer
            </p>

            {/* Core competencies */}
            <div className="flex flex-wrap gap-2 mb-6">
              {[
                language === 'pt' ? 'Aplicacoes Corporativas' : 'Corporate Applications',
                language === 'pt' ? 'Automacao' : 'Automation',
                language === 'pt' ? 'Analise de Dados' : 'Data Analysis',
                language === 'pt' ? 'Interfaces Web' : 'Web Interfaces',
              ].map((competency) => (
                <span
                  key={competency}
                  className="px-3 py-1 text-sm text-muted-foreground border border-border rounded-full"
                >
                  {competency}
                </span>
              ))}
            </div>

            {/* Description */}
            <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-8 max-w-xl">
              {t.hero.description}
            </p>

            {/* Location */}
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
              <MapPin className="w-4 h-4" />
              <span>Sao Jose dos Campos, SP</span>
              <span className="text-border mx-2">•</span>
              <span>EDP Brasil</span>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-3 gap-6 mb-10 pb-10 border-b border-border max-w-md">
              <div>
                <p className="text-3xl font-semibold text-foreground">4+</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'pt' ? 'Anos exp.' : 'Years exp.'}
                </p>
              </div>
              <div>
                <p className="text-3xl font-semibold text-foreground">5+</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'pt' ? 'Projetos' : 'Projects'}
                </p>
              </div>
              <div>
                <p className="text-3xl font-semibold text-foreground">3</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'pt' ? 'Empresas' : 'Companies'}
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="#experience"
                className="inline-flex items-center justify-center gap-2 h-11 px-6 bg-primary text-primary-foreground font-medium rounded-md hover:bg-primary/90 transition-colors"
              >
                {language === 'pt' ? 'Ver experiencia' : 'View experience'}
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href={socialLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 h-11 px-6 border border-border text-foreground font-medium rounded-md hover:bg-muted transition-colors"
              >
                <Linkedin className="w-4 h-4" />
                LinkedIn
              </a>
            </div>

            {/* Mobile tech badges */}
            <div className="flex flex-wrap gap-2 mt-10 lg:hidden">
              {techBadges.map((badge) => (
                <span
                  key={badge.name}
                  className="px-2 py-1 text-xs font-mono text-muted-foreground/60 border border-border/40 rounded"
                >
                  {badge.name}
                </span>
              ))}
            </div>
          </div>

          {/* Right - Photo placeholder */}
          <div className="hidden lg:flex justify-center">
            <div className="relative">
              {/* Photo container */}
              <div className="w-72 h-80 bg-muted/30 border border-border rounded-lg overflow-hidden relative">
                <Image
                  src="/images/profile.jpg"
                  alt="Lucas Okwok"
                  fill
                  className="object-cover object-top"
                  priority
                  onError={(e) => {
                    e.currentTarget.style.display = 'none'
                    const placeholder = e.currentTarget.parentElement?.querySelector('.placeholder-content')
                    if (placeholder) {
                      ;(placeholder as HTMLElement).style.display = 'flex'
                    }
                  }}
                />
                {/* Placeholder content shown when image fails */}
                <div className="placeholder-content hidden absolute inset-0 flex-col items-center justify-center gap-3 bg-muted/30">
                  <User className="w-16 h-16 text-muted-foreground/30" />
                  <div className="text-center px-4">
                    <p className="text-xs text-muted-foreground">
                      {language === 'pt' ? 'Adicionar foto' : 'Add photo'}
                    </p>
                    <p className="text-[10px] text-muted-foreground/60 mt-1 font-mono">
                      profile.jpg
                    </p>
                  </div>
                </div>
              </div>

              {/* Decorative border */}
              <div className="absolute -inset-3 border border-border/30 rounded-lg -z-10" />
              
              {/* Corner accents */}
              <div className="absolute -top-1 -left-1 w-4 h-4 border-t border-l border-primary/50" />
              <div className="absolute -top-1 -right-1 w-4 h-4 border-t border-r border-primary/50" />
              <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b border-l border-primary/50" />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b border-r border-primary/50" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
