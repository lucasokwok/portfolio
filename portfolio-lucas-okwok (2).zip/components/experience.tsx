'use client'

import { MapPin, Calendar, ChevronRight } from 'lucide-react'
import { useLanguage } from './language-provider'
import { experiences } from '@/lib/data'

export function Experience() {
  const { language, t } = useLanguage()

  const getCompany = (company: string | { pt: string; en: string }) => {
    return typeof company === 'string' ? company : company[language]
  }

  return (
    <section id="experience" className="py-24 lg:py-32">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section header */}
        <div className="mb-16">
          <h2 className="text-2xl sm:text-3xl font-semibold text-foreground tracking-tight mb-3">
            {t.experience.title}
          </h2>
          <p className="text-muted-foreground max-w-xl">
            Trajetoria profissional com foco em desenvolvimento de sistemas, automacao e analise de dados em ambientes corporativos.
          </p>
        </div>

        {/* Experience list */}
        <div className="space-y-0">
          {experiences.map((exp, index) => (
            <article
              key={exp.id}
              className={`group py-8 ${index !== experiences.length - 1 ? 'border-b border-border' : ''}`}
            >
              <div className="grid lg:grid-cols-12 gap-6 lg:gap-8">
                {/* Left: Company and period */}
                <div className="lg:col-span-4">
                  <div className="flex items-start gap-3">
                    <div className={`mt-1 w-2 h-2 rounded-full flex-shrink-0 ${index === 0 ? 'bg-primary' : 'bg-border'}`} />
                    <div>
                      <h3 className="font-semibold text-foreground">
                        {getCompany(exp.company)}
                      </h3>
                      <div className="mt-2 space-y-1 text-sm text-muted-foreground">
                        <p className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5" />
                          {exp.period[language]}
                        </p>
                        <p className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5" />
                          {exp.location}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right: Role and description */}
                <div className="lg:col-span-8">
                  <h4 className="text-lg font-medium text-foreground mb-3">
                    {exp.role[language]}
                  </h4>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    {exp.description[language]}
                  </p>

                  {/* Technologies */}
                  {exp.technologies && (
                    <div className="flex flex-wrap gap-2">
                      {exp.technologies.map((tech) => (
                        <span
                          key={tech}
                          className="px-2.5 py-1 text-xs font-mono bg-muted rounded text-muted-foreground"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* View more link */}
        <div className="mt-8 pt-8 border-t border-border">
          <a
            href={socialLinks.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors"
          >
            Ver perfil completo no LinkedIn
            <ChevronRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  )
}

import { socialLinks } from '@/lib/data'
