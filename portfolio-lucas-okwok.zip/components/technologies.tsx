'use client'

import { useLanguage } from './language-provider'
import { technologies } from '@/lib/data'

export function Technologies() {
  const { t } = useLanguage()

  const techCategories = [
    { key: 'webDev', title: t.technologies.webDev, items: technologies.webDev },
    { key: 'dataAutomation', title: t.technologies.dataAutomation, items: technologies.dataAutomation },
    { key: 'businessLowcode', title: t.technologies.businessLowcode, items: technologies.businessLowcode },
    { key: 'databasesTools', title: t.technologies.databasesTools, items: technologies.databasesTools },
  ]

  return (
    <section id="technologies" className="py-24 bg-secondary/30">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-12">
          {t.technologies.title}
        </h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {techCategories.map((category) => (
            <div
              key={category.key}
              className="bg-card border border-border rounded-xl p-6 space-y-4"
            >
              <h3 className="text-lg font-semibold text-foreground">
                {category.title}
              </h3>
              <div className="flex flex-wrap gap-2">
                {category.items.map((tech) => (
                  <span
                    key={tech}
                    className="px-3 py-1.5 text-sm font-mono bg-secondary rounded-md text-muted-foreground hover:text-primary transition-colors"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
