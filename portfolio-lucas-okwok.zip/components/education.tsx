'use client'

import { GraduationCap, Award } from 'lucide-react'
import { useLanguage } from './language-provider'
import { education } from '@/lib/data'

export function Education() {
  const { language, t } = useLanguage()

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'inProgress':
        return t.education.inProgress
      case 'complete':
        return t.education.complete
      case 'highlight':
        return t.education.highlight
      default:
        return ''
    }
  }

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'inProgress':
        return 'text-primary bg-primary/10'
      case 'complete':
        return 'text-accent bg-accent/10'
      case 'highlight':
        return 'text-amber-400 bg-amber-400/10'
      default:
        return 'text-muted-foreground bg-muted'
    }
  }

  return (
    <section id="education" className="py-24 bg-secondary/30">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-12">
          {t.education.title}
        </h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {education.map((edu) => (
            <article
              key={edu.id}
              className="bg-card border border-border rounded-xl p-6 space-y-4 hover:border-primary/50 transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  {edu.status === 'highlight' ? (
                    <Award className="w-6 h-6 text-amber-400" />
                  ) : (
                    <GraduationCap className="w-6 h-6 text-primary" />
                  )}
                </div>
                <span className={`text-xs font-mono px-2.5 py-1 rounded-full ${getStatusStyle(edu.status)}`}>
                  {getStatusLabel(edu.status)}
                </span>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-foreground">
                  {edu.degree[language]}
                </h3>
                <p className="text-muted-foreground">
                  {edu.institution}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
