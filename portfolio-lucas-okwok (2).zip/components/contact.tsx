'use client'

import { Github, Linkedin, Mail, ArrowUpRight } from 'lucide-react'
import { useLanguage } from './language-provider'
import { socialLinks } from '@/lib/data'

export function Contact() {
  const { t } = useLanguage()

  return (
    <section id="contact" className="py-24 lg:py-32">
      <div className="max-w-6xl mx-auto px-6">
        <div className="max-w-2xl">
          {/* Section header */}
          <h2 className="text-2xl sm:text-3xl font-semibold text-foreground tracking-tight mb-3">
            {t.contact.title}
          </h2>
          <p className="text-muted-foreground mb-10">
            {t.contact.description}
          </p>

          {/* Contact links */}
          <div className="space-y-4">
            <a
              href="mailto:contato@lucasokwok.dev"
              className="group flex items-center justify-between py-4 border-b border-border hover:border-primary/40 transition-colors"
            >
              <div className="flex items-center gap-4">
                <Mail className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                <div>
                  <p className="font-medium text-foreground">E-mail</p>
                  <p className="text-sm text-muted-foreground">contato@lucasokwok.dev</p>
                </div>
              </div>
              <ArrowUpRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
            </a>

            <a
              href={socialLinks.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-between py-4 border-b border-border hover:border-primary/40 transition-colors"
            >
              <div className="flex items-center gap-4">
                <Linkedin className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                <div>
                  <p className="font-medium text-foreground">LinkedIn</p>
                  <p className="text-sm text-muted-foreground">linkedin.com/in/lucasokwok</p>
                </div>
              </div>
              <ArrowUpRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
            </a>

            <a
              href={socialLinks.github}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-between py-4 border-b border-border hover:border-primary/40 transition-colors"
            >
              <div className="flex items-center gap-4">
                <Github className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                <div>
                  <p className="font-medium text-foreground">GitHub</p>
                  <p className="text-sm text-muted-foreground">github.com/lucasokwok</p>
                </div>
              </div>
              <ArrowUpRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
