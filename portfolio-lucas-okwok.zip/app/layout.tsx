import type { Metadata } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter'
})

const jetbrainsMono = JetBrains_Mono({ 
  subsets: ["latin"],
  variable: '--font-jetbrains'
})

export const metadata: Metadata = {
  title: 'Lucas Okwok | Desenvolvedor Full Stack',
  description: 'Desenvolvedor Full Stack com experiência em aplicações corporativas, automações, análise de dados e interfaces web modernas.',
  keywords: ['Desenvolvedor Full Stack', 'React', 'TypeScript', 'Python', 'Power BI', 'Automação'],
  authors: [{ name: 'Lucas Okwok' }],
  openGraph: {
    title: 'Lucas Okwok | Desenvolvedor Full Stack',
    description: 'Desenvolvedor Full Stack com experiência em aplicações corporativas, automações, análise de dados e interfaces web modernas.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className="bg-background">
      <body className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
