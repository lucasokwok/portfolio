'use client'

import { ArrowDown, Github, Linkedin } from 'lucide-react'
import { useLanguage } from './language-provider'
import { socialLinks } from '@/lib/data'

export function Hero() {
  const { t } = useLanguage()

  const techTags = ['React', 'TypeScript', 'Python', 'Power BI', 'Automation']

  return (
    <section className="min-h-screen flex items-center pt-20 pb-16">
      <div className="max-w-6xl mx-auto px-6 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground text-balance">
                Lucas Okwok
              </h1>
              <p className="text-xl sm:text-2xl text-primary font-medium">
                {t.hero.role}
              </p>
            </div>
            
            <p className="text-lg text-muted-foreground leading-relaxed max-w-xl text-pretty">
              {t.hero.description}
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <a
                href="#projects"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-medium rounded-lg hover:bg-primary/90 transition-colors"
              >
                {t.hero.viewProjects}
                <ArrowDown className="w-4 h-4" />
              </a>
              <a
                href={socialLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 border border-border text-foreground font-medium rounded-lg hover:bg-card hover:border-primary transition-colors"
              >
                <Linkedin className="w-4 h-4" />
                LinkedIn
              </a>
              <a
                href={socialLinks.github}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 border border-border text-foreground font-medium rounded-lg hover:bg-card hover:border-primary transition-colors"
              >
                <Github className="w-4 h-4" />
                GitHub
              </a>
            </div>
          </div>

          {/* Right Content - Photo Card */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              {/* Photo Container */}
              <div className="w-72 h-72 sm:w-80 sm:h-80 lg:w-96 lg:h-96 rounded-2xl bg-card border border-border overflow-hidden">
                <div className="w-full h-full bg-gradient-to-br from-secondary to-card flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <div className="w-32 h-32 mx-auto rounded-full bg-muted border-2 border-border flex items-center justify-center">
                      <span className="text-4xl font-bold text-primary">LO</span>
                    </div>
                    <p className="text-muted-foreground text-sm">Foto em breve</p>
                  </div>
                </div>
              </div>

              {/* Tech Tags around photo */}
              <div className="absolute -bottom-4 -left-4 flex flex-wrap gap-2 max-w-xs">
                {techTags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1.5 text-xs font-mono bg-card border border-border rounded-full text-primary"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
