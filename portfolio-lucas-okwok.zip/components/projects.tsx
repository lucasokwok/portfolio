'use client'

import { ExternalLink, Lock } from 'lucide-react'
import { useLanguage } from './language-provider'
import { projects } from '@/lib/data'

export function Projects() {
  const { language, t } = useLanguage()

  const getTitle = (title: string | { pt: string; en: string }) => {
    return typeof title === 'string' ? title : title[language]
  }

  return (
    <section id="projects" className="py-24">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-12">
          {t.projects.title}
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <article
              key={project.id}
              className="group bg-card border border-border rounded-xl overflow-hidden hover:border-primary/50 transition-colors"
            >
              {/* Project Image Placeholder */}
              <div className="aspect-video bg-secondary/50 flex items-center justify-center border-b border-border">
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 mx-auto rounded-lg bg-muted flex items-center justify-center">
                    <Lock className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <p className="text-xs text-muted-foreground font-mono">
                    {t.projects.corporateProject}
                  </p>
                </div>
              </div>

              {/* Project Content */}
              <div className="p-6 space-y-4">
                <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors">
                  {getTitle(project.title)}
                </h3>

                <p className="text-muted-foreground text-sm leading-relaxed line-clamp-3">
                  {project.description[language]}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.slice(0, 5).map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 text-xs font-mono bg-secondary rounded-md text-primary"
                    >
                      {tag}
                    </span>
                  ))}
                  {project.tags.length > 5 && (
                    <span className="px-2.5 py-1 text-xs font-mono bg-secondary rounded-md text-muted-foreground">
                      +{project.tags.length - 5}
                    </span>
                  )}
                </div>

                {/* Action */}
                <button
                  className="inline-flex items-center gap-2 text-sm text-primary hover:text-accent transition-colors pt-2"
                  disabled
                >
                  <ExternalLink className="w-4 h-4" />
                  {t.projects.viewDetails}
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
