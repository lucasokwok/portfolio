'use client'

import { useLanguage } from './language-provider'

export function About() {
  const { t } = useLanguage()

  return (
    <section id="about" className="py-24 bg-secondary/30">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-12">
          {t.about.title}
        </h2>
        
        <div className="max-w-3xl space-y-6">
          <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
            {t.about.content}
          </p>
          <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
            {t.about.education}
          </p>
        </div>
      </div>
    </section>
  )
}
