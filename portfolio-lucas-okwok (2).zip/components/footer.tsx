'use client'

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="py-8 border-t border-border">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>{currentYear} Lucas Okwok</p>
          <p>Sao Jose dos Campos, SP</p>
        </div>
      </div>
    </footer>
  )
}
