export const projects = [
  {
    id: 'hunter-map',
    title: 'Hunter Map',
    type: {
      pt: 'Web App',
      en: 'Web App',
    },
    description: {
      pt: 'Aplicacao web de navegacao em mapa para apoio a inspecoes em campo, integrando dados de modelo de machine learning para identificacao de pontos suspeitos.',
      en: 'Web-based map navigation application for field inspection support, integrating machine learning model data to identify suspicious points.',
    },
    problem: {
      pt: 'Inspetores de campo nao tinham ferramenta adequada para visualizar e priorizar pontos de inspecao indicados pelo modelo de ML, resultando em rotas ineficientes e baixa taxa de deteccao.',
      en: 'Field inspectors lacked an adequate tool to visualize and prioritize inspection points indicated by the ML model, resulting in inefficient routes and low detection rates.',
    },
    tags: ['React', 'TypeScript', 'Vite', 'Leaflet', 'REST API'],
    metric: { value: '1000+', label: { pt: 'Inspecoes gerenciadas', en: 'Inspections managed' } },
    image: '/images/projects/hunter-map.png',
  },
  {
    id: 'sap-automations',
    title: 'SAP Automations',
    type: {
      pt: 'Automacao Desktop',
      en: 'Desktop Automation',
    },
    description: {
      pt: 'Aplicativo desktop para centralizar e executar automacoes no SAP, com importacao de dados via planilhas e geracao automatica de relatorios.',
      en: 'Desktop application to centralize and execute SAP automations, with data import via spreadsheets and automatic report generation.',
    },
    problem: {
      pt: 'Processos manuais repetitivos no SAP consumiam horas de trabalho da equipe, com alta taxa de erros e retrabalho em tarefas como cadastros e atualizacoes em massa.',
      en: 'Repetitive manual processes in SAP consumed hours of team work, with high error rates and rework on tasks like registrations and bulk updates.',
    },
    tags: ['Python', 'Tkinter', 'OpenPyXL', 'SAP GUI Scripting'],
    metric: { value: '500+', label: { pt: 'Horas automatizadas', en: 'Hours automated' } },
    image: '/images/projects/sap-automations.png',
  },
  {
    id: 'minha-primeira-automacao',
    title: {
      pt: 'Minha Primeira Automacao',
      en: 'My First Automation',
    },
    type: {
      pt: 'Automacao Juridica',
      en: 'Legal Automation',
    },
    description: {
      pt: 'Software desktop para geracao automatica de documentos juridicos em lote, produzindo arquivos DOCX e PDF individualizados a partir de templates e planilhas.',
      en: 'Desktop software for automatic batch generation of legal documents, producing individualized DOCX and PDF files from templates and spreadsheets.',
    },
    problem: {
      pt: 'Escritorio juridico gastava dias criando cartas de notificacao manualmente, copiando dados de planilhas para documentos Word um a um, processo sujeito a erros.',
      en: 'Law office spent days creating notification letters manually, copying data from spreadsheets to Word documents one by one, an error-prone process.',
    },
    tags: ['Python', 'Tkinter', 'python-docx', 'ReportLab'],
    metric: { value: '5000+', label: { pt: 'Documentos gerados', en: 'Documents generated' } },
    image: '/images/projects/minha-primeira-automacao.png',
  },
  {
    id: 'parking-app',
    title: 'Parking App',
    type: {
      pt: 'Power Apps',
      en: 'Power Apps',
    },
    description: {
      pt: 'Aplicativo corporativo de reservas de vagas de estacionamento, com controle de disponibilidade em tempo real e integracao com SharePoint.',
      en: 'Corporate parking spot reservation app, with real-time availability control and SharePoint integration.',
    },
    problem: {
      pt: 'Funcionarios disputavam vagas de estacionamento sem organizacao, gerando conflitos e perda de tempo. Nao havia visibilidade sobre disponibilidade.',
      en: 'Employees competed for parking spots without organization, generating conflicts and wasted time. There was no visibility on availability.',
    },
    tags: ['Power Apps', 'Power Automate', 'SharePoint'],
    metric: { value: '100+', label: { pt: 'Usuarios ativos', en: 'Active users' } },
    image: '/images/projects/parking-app.png',
  },
  {
    id: 'power-bi-dashboard',
    title: {
      pt: 'Painel Power BI de Gestao de Metas',
      en: 'Power BI Goals Management Dashboard',
    },
    type: {
      pt: 'Business Intelligence',
      en: 'Business Intelligence',
    },
    description: {
      pt: 'Dashboard executivo para acompanhamento de metas e desempenho operacional, com comparativos Real x Meta e analise de tendencias.',
      en: 'Executive dashboard for tracking goals and operational performance, with Actual vs Target comparisons and trend analysis.',
    },
    problem: {
      pt: 'Gestores nao tinham visao consolidada do desempenho das equipes. Relatorios eram gerados manualmente em Excel, defasados e inconsistentes.',
      en: 'Managers lacked a consolidated view of team performance. Reports were generated manually in Excel, outdated and inconsistent.',
    },
    tags: ['Power BI', 'DAX', 'SQL', 'Data Modeling'],
    metric: { value: 'Diario', label: { pt: 'Suporte a decisoes', en: 'Decision support' } },
    image: '/images/projects/power-bi-dashboard.png',
  },
]

export const experiences = [
  {
    id: 'edp',
    company: 'EDP Brasil',
    role: {
      pt: 'Estagiario em Desenvolvimento de Sistemas e Analise de Dados',
      en: 'Systems Development and Data Analysis Intern',
    },
    period: {
      pt: 'out/2025 - atual',
      en: 'Oct/2025 - present',
    },
    location: 'Sao Jose dos Campos, SP',
    description: {
      pt: 'Desenvolvimento de aplicacoes e sistemas voltados a estrategia de combate as perdas, com atuacao em analise de dados, dashboards, automacoes e melhoria de processos internos relacionados a tecnologia e processamento de dados.',
      en: 'Development of applications and systems focused on loss reduction strategy, working with data analysis, dashboards, automations, and improvement of internal processes related to technology and data processing.',
    },
    technologies: ['Python', 'Power BI', 'Power Apps', 'React', 'TypeScript'],
  },
  {
    id: 'control2',
    company: 'Control2 Sistemas',
    role: {
      pt: 'Desenvolvedor Full Stack — Estagio',
      en: 'Full Stack Developer — Internship',
    },
    period: {
      pt: 'fev/2023 - ago/2023',
      en: 'Feb/2023 - Aug/2023',
    },
    location: 'Sao Jose dos Campos, SP',
    description: {
      pt: 'Atuacao em desenvolvimento full stack, pesquisas tecnicas e testes com reconhecimento de placas veiculares, utilizando tecnologias como C#, Java, JavaScript, SQL e MongoDB.',
      en: 'Full stack development, technical research, and testing with license plate recognition, using technologies such as C#, Java, JavaScript, SQL, and MongoDB.',
    },
    technologies: ['C#', 'Java', 'JavaScript', 'SQL', 'MongoDB'],
  },
  {
    id: 'exercito',
    company: {
      pt: 'Exercito Brasileiro',
      en: 'Brazilian Army',
    },
    role: {
      pt: 'Auxiliar de Informatica',
      en: 'IT Assistant',
    },
    period: {
      pt: 'mar/2022 - jan/2023',
      en: 'Mar/2022 - Jan/2023',
    },
    location: 'Cacapava, SP',
    description: {
      pt: 'Manutencao de rede interna, configuracao de equipamentos de infraestrutura, manipulacao de proxy, suporte tecnico e administracao de dispositivos como access points, PTPs e switches gerenciaveis.',
      en: 'Internal network maintenance, infrastructure equipment configuration, proxy management, technical support, and administration of devices such as access points, PTPs, and managed switches.',
    },
    technologies: ['Network', 'Infrastructure', 'Technical Support'],
  },
  {
    id: 'valltech',
    company: 'Valltech - Tecnologia em Automacao',
    role: {
      pt: 'Desenvolvedor Full Stack / Suporte Tecnico',
      en: 'Full Stack Developer / Technical Support',
    },
    period: {
      pt: 'nov/2020 - ago/2021',
      en: 'Nov/2020 - Aug/2021',
    },
    location: 'Sao Jose dos Campos, SP',
    description: {
      pt: 'Atuacao em suporte tecnico, manutencao de sistemas, restauracao de backups, instalacao de solucoes corporativas e desenvolvimento de software com C#, Java e Visual Basic.',
      en: 'Technical support, system maintenance, backup restoration, corporate solution installation, and software development with C#, Java, and Visual Basic.',
    },
    technologies: ['C#', 'Java', 'Visual Basic'],
  },
]

export const education = [
  {
    id: 'unifesp-cc',
    institution: 'UNIFESP',
    degree: {
      pt: 'Bacharelado em Ciencia da Computacao',
      en: "Bachelor's in Computer Science",
    },
    status: 'inProgress',
  },
  {
    id: 'unifesp-ct',
    institution: 'UNIFESP',
    degree: {
      pt: 'Bacharelado em Ciencia e Tecnologia',
      en: "Bachelor's in Science and Technology",
    },
    status: 'complete',
  },
  {
    id: 'univap',
    institution: 'UNIVAP Colegios',
    degree: {
      pt: 'Tecnico em Informatica',
      en: 'Technical Degree in Information Technology',
    },
    status: 'highlight',
  },
]

export const technologies = {
  webDev: ['React', 'TypeScript', 'Vite', 'JavaScript', 'HTML', 'CSS'],
  dataAutomation: ['Python', 'Pandas', 'OpenPyXL', 'Web Scraping', 'SAP Automation'],
  businessLowcode: ['Power BI', 'Power Apps', 'Power Automate', 'SharePoint'],
  databasesTools: ['SQL', 'MongoDB', 'Git', 'GitHub', 'Vercel'],
}

export const socialLinks = {
  linkedin: 'https://www.linkedin.com/in/lucasokwok',
  github: 'https://github.com/lucasokwok',
}
