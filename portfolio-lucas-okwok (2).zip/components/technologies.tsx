'use client'

import { useLanguage } from './language-provider'
import { technologies } from '@/lib/data'

export function Technologies() {
  const { t } = useLanguage()

  const techCategories = [
    { 
      key: 'webDev', 
      title: t.technologies.webDev, 
      items: technologies.webDev,
    },
    { 
      key: 'dataAutomation', 
      title: t.technologies.dataAutomation, 
      items: technologies.dataAutomation,
    },
    { 
      key: 'businessLowcode', 
      title: t.technologies.businessLowcode, 
      items: technologies.businessLowcode,
    },
    { 
      key: 'databasesTools', 
      title: t.technologies.databasesTools, 
      items: technologies.databasesTools,
    },
  ]

  return (
    <section id="technologies" className="py-24 lg:py-32">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section header */}
        <div className="mb-16">
          <h2 className="text-2xl sm:text-3xl font-semibold text-foreground tracking-tight mb-3">
            {t.technologies.title}
          </h2>
          <p className="text-muted-foreground max-w-xl">
            Tecnologias e ferramentas que domino para entregar solucoes de qualidade.
          </p>
        </div>

        {/* Tech categories */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {techCategories.map((category) => (
            <div key={category.key}>
              <h3 className="text-sm font-medium text-foreground mb-4">
                {category.title}
              </h3>
              <ul className="space-y-2">
                {category.items.map((tech) => (
                  <li
                    key={tech}
                    className="text-sm text-muted-foreground flex items-center gap-2"
                  >
                    <span className="w-1 h-1 rounded-full bg-primary" />
                    {tech}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
